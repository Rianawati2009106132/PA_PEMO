import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class detail extends StatelessWidget {
  String Judul;
  String Harga;
  String Deskripsi;
  String foto;
  String whatsapp;
  detail({
    Key? key,
    required this.Judul,
    required this.Harga,
    required this.Deskripsi,
    required this.foto,
    required this.whatsapp,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          'Detail Page',
          style: GoogleFonts.barlowCondensed(
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
          textAlign: TextAlign.center,
        ),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
              tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
              icon: Icon(Icons.menu),
              iconSize: 25,
              color: Colors.black,
            );
          },
        ),
      ),
    );
  }
}
