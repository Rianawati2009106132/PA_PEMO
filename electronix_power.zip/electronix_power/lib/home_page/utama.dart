import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:electronix_power/Color/color.dart';
import 'package:electronix_power/Controllers/FirestoreController.dart';
import 'package:electronix_power/Controllers/TextController.dart';
import 'package:electronix_power/Pager/detail.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class utama extends StatelessWidget {
  utama({super.key});

  FirestoreController fsc = Get.put(FirestoreController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.only(left: 10, right: 10, top: 20),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width / 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Discover',
                          style: GoogleFonts.barlowCondensed(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'New Collections',
                          style: GoogleFonts.barlowCondensed(
                            fontSize: 18,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                    child: Container(
                  child: TextField(
                    textAlign: TextAlign.center,
                    onChanged: ((value) {}),
                    // controller: ,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color: Colors.grey.withOpacity(0.2),
                          )),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(
                          color: Colors.grey.withOpacity(0.2),
                        ),
                      ),
                      hintText: "Search",
                      suffixIcon: Icon(
                        Icons.people,
                        color: Color.fromARGB(255, 114, 111, 111),
                      ),
                      hintStyle: GoogleFonts.barlowCondensed(
                        fontSize: 16,
                        color: Color.fromARGB(255, 114, 111, 111),
                      ),
                      fillColor: Colors.grey.withOpacity(0.2),
                      filled: true,
                    ),
                  ),
                )),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 170,
              decoration: BoxDecoration(
                color: birugelap,
                borderRadius: BorderRadius.all(Radius.circular(10)),
                image: DecorationImage(
                  image: AssetImage("assets/logo.png"),
                ),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 94,
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    padding: EdgeInsets.only(left: 20),
                    child: Text(
                      'Camera Payday',
                      style: GoogleFonts.barlowCondensed(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width / 1.65,
                        alignment: Alignment.topLeft,
                        padding: EdgeInsets.only(left: 20),
                        child: Text(
                          '70% off all Item',
                          style: GoogleFonts.barlowCondensed(
                            fontSize: 17,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      Container(
                        width: 90,
                        child: TextButton(
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          onPressed: (() {}),
                          child: Text(
                            'Buy Now',
                            style: GoogleFonts.barlow(
                              fontSize: 13,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: MediaQuery.of(context).size.height - 419,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: birugelap,
              ),
              child: ListView(
                children: [
                  StreamBuilder<QuerySnapshot>(
                    stream: fsc.brg.value.snapshots(),
                    builder: ((context, snapshot) {
                      return snapshot.hasData
                          ? Column(
                              children: snapshot.data!.docs
                                  .map(
                                    (e) => Container(
                                      margin: EdgeInsets.only(
                                          left: 3, right: 3, top: 3),
                                      color: biruterang,
                                      child: ListTile(
                                        leading: Image(
                                            fit: BoxFit.cover,
                                            image: NetworkImage(
                                                '${e.get('foto')}')),
                                        title: Text("${e.get('Judul')}"),
                                        subtitle: Text("${e.get('harga')}"),
                                        trailing: IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                                Icons.add_shopping_cart_sharp)),
                                        selectedTileColor: birugelap,
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (_) {
                                              return GestureDetector(
                                                onTap: () {
                                                  Navigator.of(context)
                                                      .pushReplacement(
                                                          MaterialPageRoute(
                                                    builder: (context) =>
                                                        detail(
                                                      Judul: e.get('Judul'),
                                                      Harga: e.get('Owner'),
                                                      foto: '',
                                                      Deskripsi: '',
                                                      whatsapp: '',
                                                    ),
                                                  ));
                                                },
                                              );
                                            }),
                                          );
                                        },
                                      ),
                                    ),
                                  )
                                  .toList(),
                            )
                          : Center(
                              child: Text('Tidak Ada Barang Yang Dijual !',
                                  textAlign: TextAlign.center),
                            );
                    }),
                  ),
                ],
              ),
              // Column(
              //   children: [
              //     StreamBuilder<QuerySnapshot>(
              //       stream: fsc.brg.value.snapshots(),
              //       builder: ((context, snapshot) {
              //         return snapshot.hasData
              //             ? GridView.count(
              //                 crossAxisCount: 2,
              //                 children: snapshot.data!.docs
              //                     .map(
              //                       (e) => Container(
              //                         margin: EdgeInsets.all(2),
              //                         width:
              //                             MediaQuery.of(context).size.width / 2,
              //                         height: 200,
              //                         // color: Colors.grey,
              //                         child: Column(
              //                           children: [
              //                             Container(
              //                               height: 100,
              //                               width: MediaQuery.of(context)
              //                                   .size
              //                                   .width,
              //                               decoration: BoxDecoration(
              //                                   image: DecorationImage(
              //                                     image: AssetImage(
              //                                         "${e.get('foto')}"),
              //                                   ),
              //                                   color: Colors.blue,
              //                                   borderRadius:
              //                                       BorderRadius.circular(10)),
              //                             ),
              //                             Row(
              //                               children: [
              //                                 Container(
              //                                   width: MediaQuery.of(context)
              //                                           .size
              //                                           .width /
              //                                       3.06,
              //                                   child: Column(
              //                                     children: [
              //                                       Container(
              //                                         padding: EdgeInsets.only(
              //                                             left: 5,
              //                                             right: 5,
              //                                             top: 3),
              //                                         alignment:
              //                                             Alignment.topLeft,
              //                                         child: Text(
              //                                           '${e.get('Judul')}',
              //                                           style: GoogleFonts
              //                                               .barlowCondensed(
              //                                                   fontSize: 15,
              //                                                   fontWeight:
              //                                                       FontWeight
              //                                                           .bold),
              //                                         ),
              //                                       ),
              //                                       Container(
              //                                         padding: EdgeInsets.only(
              //                                             left: 5,
              //                                             right: 5,
              //                                             top: 5),
              //                                         alignment:
              //                                             Alignment.topLeft,
              //                                         child: Text(
              //                                           'Rp.${e.get('Owner')}',
              //                                           style: GoogleFonts
              //                                               .barlowCondensed(
              //                                             fontSize: 14,
              //                                           ),
              //                                         ),
              //                                       ),
              //                                     ],
              //                                   ),
              //                                 ),
              //                                 Container(
              //                                   alignment: Alignment.centerLeft,
              //                                   child: IconButton(
              //                                       onPressed: () {},
              //                                       icon: Icon(
              //                                         Icons.favorite,
              //                                         color: Colors.red,
              //                                       )),
              //                                 )
              //                               ],
              //                             ),
              //                           ],
              //                         ),
              //                       ),
              //                     )
              //                     .toList(),
              //               )
              //             : Center(
              //                 child: Text('Daftar Buku Saya'),
              //               );
              //       }),
              //     ),
              // Container(
              //   margin: EdgeInsets.all(2),
              //   width: MediaQuery.of(context).size.width / 2,
              //   height: 200,
              //   // color: Colors.grey,
              //   child: Column(
              //     children: [
              //       Container(
              //         height: 100,
              //         width: MediaQuery.of(context).size.width,
              //         decoration: BoxDecoration(
              //             image: DecorationImage(
              //               image: AssetImage("assets/logo.png"),
              //             ),
              //             color: Colors.blue,
              //             borderRadius: BorderRadius.circular(10)),
              //       ),
              //       Row(
              //         children: [
              //           Container(
              //             width: MediaQuery.of(context).size.width / 3.06,
              //             child: Column(
              //               children: [
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 3),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Maspion EX 1010',
              //                     style: GoogleFonts.barlowCondensed(
              //                         fontSize: 15,
              //                         fontWeight: FontWeight.bold),
              //                   ),
              //                 ),
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 5),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Rp.10000',
              //                     style: GoogleFonts.barlowCondensed(
              //                       fontSize: 14,
              //                     ),
              //                   ),
              //                 ),
              //               ],
              //             ),
              //           ),
              //           Container(
              //             alignment: Alignment.centerLeft,
              //             child: IconButton(
              //                 onPressed: () {},
              //                 icon: Icon(
              //                   Icons.favorite,
              //                   color: Colors.red,
              //                 )),
              //           )
              //         ],
              //       ),
              //     ],
              //   ),
              // ),
              // Container(
              //   margin: EdgeInsets.all(2),
              //   width: MediaQuery.of(context).size.width / 2,
              //   height: 200,
              //   // color: Colors.grey,
              //   child: Column(
              //     children: [
              //       Container(
              //         height: 100,
              //         width: MediaQuery.of(context).size.width,
              //         decoration: BoxDecoration(
              //             image: DecorationImage(
              //               image: AssetImage("assets/logo.png"),
              //             ),
              //             color: Colors.blue,
              //             borderRadius: BorderRadius.circular(10)),
              //       ),
              //       Row(
              //         children: [
              //           Container(
              //             width: MediaQuery.of(context).size.width / 3.06,
              //             child: Column(
              //               children: [
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 3),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Maspion EX 1010',
              //                     style: GoogleFonts.barlowCondensed(
              //                         fontSize: 15,
              //                         fontWeight: FontWeight.bold),
              //                   ),
              //                 ),
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 5),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Rp.10000',
              //                     style: GoogleFonts.barlowCondensed(
              //                       fontSize: 14,
              //                     ),
              //                   ),
              //                 ),
              //               ],
              //             ),
              //           ),
              //           Container(
              //             alignment: Alignment.centerLeft,
              //             child: IconButton(
              //                 onPressed: () {},
              //                 icon: Icon(
              //                   Icons.favorite,
              //                   color: Colors.red,
              //                 )),
              //           )
              //         ],
              //       ),
              //     ],
              //   ),
              // ),
              // Container(
              //   margin: EdgeInsets.all(2),
              //   width: MediaQuery.of(context).size.width / 2,
              //   height: 200,
              //   // color: Colors.grey,
              //   child: Column(
              //     children: [
              //       Container(
              //         height: 100,
              //         width: MediaQuery.of(context).size.width,
              //         decoration: BoxDecoration(
              //             image: DecorationImage(
              //               image: AssetImage("assets/logo.png"),
              //             ),
              //             color: Colors.blue,
              //             borderRadius: BorderRadius.circular(10)),
              //       ),
              //       Row(
              //         children: [
              //           Container(
              //             width: MediaQuery.of(context).size.width / 3.06,
              //             child: Column(
              //               children: [
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 3),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Maspion EX 1010',
              //                     style: GoogleFonts.barlowCondensed(
              //                         fontSize: 15,
              //                         fontWeight: FontWeight.bold),
              //                   ),
              //                 ),
              //                 Container(
              //                   padding: EdgeInsets.only(
              //                       left: 5, right: 5, top: 5),
              //                   alignment: Alignment.topLeft,
              //                   child: Text(
              //                     'Rp.10000',
              //                     style: GoogleFonts.barlowCondensed(
              //                       fontSize: 14,
              //                     ),
              //                   ),
              //                 ),
              //               ],
              //             ),
              //           ),
              //           Container(
              //             alignment: Alignment.centerLeft,
              //             child: IconButton(
              //                 onPressed: () {},
              //                 icon: Icon(
              //                   Icons.favorite,
              //                   color: Colors.red,
              //                 )),
              //           )
              //         ],
              //       ),
              //     ],
              //   ),
              // ),
              // ],
              // ),
              // ListView(
              //   children: [
              //     Container(
              //       child: GridView.count(
              //         crossAxisCount: 2,
              //         children: [
              // StreamBuilder<QuerySnapshot>(
              //   stream: fsc.data.value.snapshots(),
              //   builder: ((context, snapshot) {
              //     return snapshot.hasData
              //         ? Column(
              //             children: snapshot.data!.docs
              //                 .map(
              //                   (e) => Container(
              //                     margin: EdgeInsets.only(
              //                         left: 10, right: 10, top: 3),
              //                     color: Color.fromRGBO(168, 219, 168, 1),
              //                     child: ListTile(
              //                       leading: Image.asset('${e.get('foto')}',
              //                           fit: BoxFit.cover),
              //                       title: Text("${e.get('Judul')}"),
              //                       subtitle: Text("${e.get('Owner')}"),
              //                       trailing: TextButton(
              //                         onPressed: () {
              //                           Navigator.push(
              //                             context,
              //                             MaterialPageRoute(builder: (_) {
              //                               return GestureDetector(
              //                                 onTap: () {
              //                                   Navigator.push(
              //                                     context,
              //                                     MaterialPageRoute(
              //                                       builder: (_) => detail(
              //                                         Judul: e.get('Judul'),
              //                                         Owner: e.get('Isi'),
              //                                         Deskripsi: '',
              //                                         foto: '',
              //                                         whatsapp: '',
              //                                       ),
              //                                     ),
              //                                   );
              //                                 },
              //                               );
              //                             }),
              //                           );
              //                         },
              //                         child: Text(
              //                           'Read More',
              //                           style: GoogleFonts.actor(
              //                             fontSize: 12,
              //                             color: Colors.white,
              //                           ),
              //                         ),
              //                       ),
              //                       selectedTileColor: background,
              //                       onTap: () {
              //                         Navigator.push(
              //                           context,
              //                           MaterialPageRoute(builder: (_) {
              //                             return GestureDetector(
              //                               onTap: () {
              //                                 Navigator.push(
              //                                   context,
              //                                   MaterialPageRoute(
              //                                     builder: (_) => detail(
              //                                       Judul: e.get('Judul'),
              //                                       Owner: e.get('Isi'),
              //                                       Deskripsi: '',
              //                                       whatsapp: '',
              //                                       foto: '',
              //                                     ),
              //                                   ),
              //                                 );
              //                               },
              //                             );
              //                           }),
              //                         );
              //                       },
              //                     ),
              //                   ),
              //                 )
              //                 .toList(),
              //           )
              //         : Center(
              //             child: Text("Tidak ada barang yang dijual"),
              //           );
              //   }),
              // ),
              //         ],
              //       ),
              //     ),
              //   ],
              // )
            ),
          ],
        ),
      ),
    );
  }
}
