package com.example.electronix_power

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
